export interface Task {
    id: number;
    text: string;
    completed: boolean;
  }
  
  export type TaskAction =
    | { type: 'ADD_TASK'; text: string }
    | { type: 'TOGGLE_TASK'; id: number }
    | { type: 'DELETE_TASK'; id: number }
    | { type: 'UPDATE_TASK'; task: Task };
  
  export interface TaskFormProps {
    onSubmit: (e: React.FormEvent) => void;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    placeholder: string;
    buttonText: string;
    inputRef?: React.RefObject<HTMLInputElement>;
    secondaryButtonText?: string;
    onSecondaryButtonClick?: () => void;
  }
  
  export interface TaskProps {
    task: Task;
    onToggle: (id: number) => void;
    onEdit: (task: Task) => void;
    onDelete: (id: number) => void;
  }
  
  export interface TaskListProps {
    tasks: Task[];
    onToggle: (id: number) => void;
    onEdit: (task: Task) => void;
    onDelete: (id: number) => void;
  }
  
  export interface StatsProps {
    total: number;
    completed: number;
  }
  
  export interface ThemeToggleProps {
    darkMode: boolean;
    toggleTheme: () => void;
  }