import React from 'react';
import type { TaskFormProps } from '../Types/taskTypes';

const TaskForm: React.FC<TaskFormProps> = ({
  onSubmit,
  value,
  onChange,
  placeholder,
  buttonText,
  inputRef,
  secondaryButtonText,
  onSecondaryButtonClick
}) => {
  return (
    <form onSubmit={onSubmit}>
      <input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        ref={inputRef ?? undefined}  
      />
      <button type="submit">{buttonText}</button>
      {secondaryButtonText && onSecondaryButtonClick && (
        <button type="button" onClick={onSecondaryButtonClick}>
          {secondaryButtonText}
        </button>
      )}
    </form>
  );
};

export default TaskForm;
