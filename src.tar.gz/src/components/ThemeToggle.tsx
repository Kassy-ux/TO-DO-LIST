import React from 'react';
import type { ThemeToggleProps } from '../Types/taskTypes';

const ThemeToggle: React.FC<ThemeToggleProps> = ({ darkMode, toggleTheme }) => {
  return (
    <button 
      onClick={toggleTheme}
      className="theme-toggle"
    >
      {darkMode ? '☀️ Light Mode' : '🌙 Dark Mode'}
    </button>
  );
};

export default ThemeToggle;