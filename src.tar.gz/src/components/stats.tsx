import React from 'react';
import type { StatsProps } from '../Types/taskTypes';

const Stats: React.FC<StatsProps> = ({ total, completed }) => {
  return (
    <div className="stats">
      <p>Total Tasks: {total}</p>
      <p>Completed: {completed}</p>
    </div>
  );
};

export default Stats;