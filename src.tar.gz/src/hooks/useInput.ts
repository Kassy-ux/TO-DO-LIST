import { useState, useRef, type ChangeEvent } from 'react';

export const useInput = (initialValue: string) => {
  const [value, setValue] = useState(initialValue);


  const ref = useRef<HTMLInputElement>(null!) as React.RefObject<HTMLInputElement>;

  const onChange = (e: ChangeEvent<HTMLInputElement>) => {
    setValue(e.target.value);
  };

  return {
    value,
    onChange,
    ref,
    setValue
  };
};
