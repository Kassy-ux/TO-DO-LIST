import React, {
  useReducer,
  useMemo,
  useCallback,
  useEffect,
  useState,
  useRef
} from 'react';
import { useInput } from './hooks/useInput';
import type { Task, TaskAction } from './Types/taskTypes';
import TaskForm from './components/TaskForm';
import TaskList from './components/TaskList';
import Stats from './components/stats';
import ThemeToggle from './components/ThemeToggle';
import bgImage from './assets/image.jpeg'; 
import './App.css'; 

function tasksReducer(state: Task[], action: TaskAction): Task[] {
  switch (action.type) {
    case 'ADD_TASK':
      return [...state, { id: Date.now(), text: action.text, completed: false }];
    case 'TOGGLE_TASK':
      return state.map(task =>
        task.id === action.id ? { ...task, completed: !task.completed } : task
      );
    case 'DELETE_TASK':
      return state.filter(task => task.id !== action.id);
    case 'UPDATE_TASK':
      return state.map(task =>
        task.id === action.task.id ? { ...task, text: action.task.text } : task
      );
    default:
      return state;
  }
}

const App: React.FC = () => {
  const [tasks, dispatch] = useReducer(tasksReducer, []);
  const [darkMode, setDarkMode] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [currentTask, setCurrentTask] = useState<Task | null>(null);
  const taskInput = useInput('');
  const editInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing && editInput.current) editInput.current.focus();
  }, [isEditing]);

  const taskCount = useMemo(() => tasks.length, [tasks]);
  const completedCount = useMemo(
    () => tasks.filter(task => task.completed).length,
    [tasks]
  );

  const handleAddTask = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      if (taskInput.value.trim()) {
        dispatch({ type: 'ADD_TASK', text: taskInput.value });
        taskInput.setValue('');
      }
    },
    [taskInput]
  );

  const handleToggleTask = useCallback((id: number) => {
    dispatch({ type: 'TOGGLE_TASK', id });
  }, []);

  const handleDeleteTask = useCallback((id: number) => {
    dispatch({ type: 'DELETE_TASK', id });
  }, []);

  const handleEditTask = useCallback(
    (task: Task) => {
      setIsEditing(true);
      setCurrentTask(task);
      taskInput.setValue(task.text);
    },
    [taskInput]
  );

  const handleUpdateTask = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      if (taskInput.value.trim() && currentTask) {
        dispatch({
          type: 'UPDATE_TASK',
          task: { ...currentTask, text: taskInput.value }
        });
        setIsEditing(false);
        setCurrentTask(null);
        taskInput.setValue('');
      }
    },
    [taskInput, currentTask]
  );

  const cancelEdit = useCallback(() => {
    setIsEditing(false);
    setCurrentTask(null);
    taskInput.setValue('');
  }, [taskInput]);

  const toggleTheme = useCallback(() => {
    setDarkMode(prev => !prev);
  }, []);

  return (
    <div className={`app ${darkMode ? 'dark' : 'light'}`}>
      
      <div className="hero" style={{ backgroundImage: `url(${bgImage})` }}>
        <div className="overlay" />
        <h1 className="title">TODO</h1>
      </div>

      <div className="container">
        <ThemeToggle darkMode={darkMode} toggleTheme={toggleTheme} />
        <Stats total={taskCount} completed={completedCount} />

        <TaskForm
          onSubmit={isEditing ? handleUpdateTask : handleAddTask}
          value={taskInput.value}
          onChange={taskInput.onChange}
          placeholder={isEditing ? 'Edit task...' : 'Add a new task...'}
          buttonText={isEditing ? 'Update' : 'Add'}
          inputRef={isEditing ? editInput : taskInput.ref}
          secondaryButtonText={isEditing ? 'Cancel' : undefined}
          onSecondaryButtonClick={isEditing ? cancelEdit : undefined}
        />

        <div className="task-list">
          <TaskList
            tasks={tasks}
            onToggle={handleToggleTask}
            onEdit={handleEditTask}
            onDelete={handleDeleteTask}
          />
        </div>
      </div>
    </div>
  );
};

export default App;
